


window.onpopstate = function(event) {

  if(event.state.foo == 'pagina' && GL_POSICION_NAVEGACION_PAGINA=='viendo_noticia'){

  	GL_POSICION_NAVEGACION_PAGINA=event.state.foo;
  	fun_ocultar_visor_portafolios();

  }
};

var GL_POSICION_NAVEGACION_PAGINA='pagina';
var GL_CONTEO_REGRESIVO_BUSQUEDA;

$(document).ready(function(){



var stateObj = { foo: "pagina" };
window.history.replaceState(stateObj, null, document.location);



	fun_resize();


var cuenta_ondas=0;
  $('body').click(function(event){
     x=event.pageX;

	scroll_top=((document.body.scrollTop)? document.body.scrollTop : document.documentElement.scrollTop);

     y=event.pageY-scroll_top;

     $('#lienzo_click').append('<div id="onda-'+cuenta_ondas+'" class="onda" style="top:'+(y-75)+'px;left:'+(x-75)+'px;"></div>');

     var delay=setInterval(function(id){
      clearInterval(delay);
      $('#lienzo_click #onda-'+id).remove();
     },3000,cuenta_ondas);
    cuenta_ondas++;

  });














		$('body').on('click','#portafolios .noticia-leer_mas',function(){

			$('#portafolios .comp-visor-fotos .comp-visor-fotos-content .comp-visor-foto.select .noticia-leer_mas_oculto').click();

		});

		$('body').on('click','#portafolios .noticia-leer_mas_oculto',function(){

			id=$(this).data('id_noticia');
			fun_mostrar_info_noticia(id);

		});

var GL_BLOQUEO_BTN_VISOR_FOTOS=false;
		$('body').on('click','#portafolios .comp-visor-fotos.mitad .comp-vf-btn',function(){
			if(!GL_BLOQUEO_BTN_VISOR_FOTOS){
				GL_BLOQUEO_BTN_VISOR_FOTOS=true;


				$('.content_visor_detalles').addClass('oculto');
				$('.noticia_detalles .botones_sociales_noticia').html('');
				$('#content_visor_detalles_portafolios .comentarios_noticia').html('');
		

				var top_portafolios=$('#portafolios').offset().top;
				$('html').scrollTop(top_portafolios);
			    

			    if($(window).width()>700){

					var delay=setInterval(function(){
						clearInterval(delay);

						$('#portafolios .comp-visor-fotos .comp-visor-fotos-content .comp-visor-foto.select .noticia-leer_mas_oculto').click();
						GL_BLOQUEO_BTN_VISOR_FOTOS=false;
					},500);			

			    }
			}
		});

		$('body').on('click','#visor_portafolios .regresar',function(){

			window.history.back();

		});

/*
		$('body').on('click','#visor_portafolios .columna .cg-contenedor-nav .cg-nav-btn',function(){			
			id_galeria=$(this).data('idgaleria');		
			$('#visor_portafolios .columna .cg-contenedor-nav .cg-nav-btn').removeClass('activo');
			$(this).addClass('activo');
		});

*/




	$('body').on('click','#cambiar_modo_busqueda',function(){

		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').click();

	});



	$('.barra_content .seccion_inputs .seccion_icono').click(function(){

		if($(this).data('opcion')=='noticias' || $(this).data('opcion')=='contacto'){

			if($('#barra_de_busqueda').data('posicion')=='inferior'){


			}else{
				/*if($(window).width()>800){

					fun_animacion_ocultar_espacio_busqueda(true);
				}else{
*/

					var top_portafolios=$('#portafolios').offset().top;

					$('html,body').animate({scrollTop:top_portafolios},1000);
			
				//}

			}


		}else{
			if($(this).data('opcion')!=$('.barra_content .seccion_inputs .seccion_icono.select').data('opcion')){

				if($('#barra_de_busqueda').data('posicion')=='inferior'){

					if($(this).data('opcion')!='atras'){

						$('.barra_content .seccion_inputs .seccion_icono').removeClass('select');
						$('.barra_content .seccion_inputs .seccion_icono').removeClass('sin_selec_1');
						$('.barra_content .seccion_inputs .seccion_icono').removeClass('sin_selec_2');
						$('.barra_content .seccion_inputs .seccion_icono').removeClass('sin_selec_3');

						$(this).addClass('select');
						var opcion=$(this).data('opcion');
						cont=1;
						$('.barra_content .seccion_inputs .seccion_icono').each(function(){
							if(opcion!=$(this).data('opcion') && $(this).data('opcion')!='atras'){
								$(this).addClass('sin_selec_'+cont);
								cont++;
							}			
						});

						if($(this).data('opcion')=='buscar'){
							width_buscador=$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_borde_buscador').css('width');
							$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_borde_buscador').css('width',width_buscador);
						}

						$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');
						var delay=setInterval(function(){
							clearInterval(delay);
							$('#barra_de_busqueda .seccion_content_funciones #seccion_funcion-'+opcion).removeClass('oculto');
						},1500);


						$('#inicio #barra_de_busqueda').removeClass('seccion-buscar');
						$('#inicio #barra_de_busqueda').removeClass('seccion-vender');
						$('#inicio #barra_de_busqueda').removeClass('seccion-ayuda');
						$('#inicio #barra_de_busqueda').addClass('seccion-'+opcion);

					}

				}else{

					if($(this).data('opcion')!='atras' ){


							if(!$('.barra_content .seccion_inputs #btn_atras').hasClass('oculto')){
								$('.barra_content .seccion_inputs #btn_atras').click();
							}

							$('.barra_content .seccion_inputs .seccion_icono').removeClass('select');
							$('.barra_content .seccion_inputs .seccion_icono').removeClass('sin_selec_1');
							$('.barra_content .seccion_inputs .seccion_icono').removeClass('sin_selec_2');
							$('.barra_content .seccion_inputs .seccion_icono').removeClass('sin_selec_3');

							$('#barra_de_busqueda .content_resultados_avisos').addClass('oculto');

							$('#inicio #barra_de_busqueda .seccion_content_funciones').removeClass('no_events');

							$(this).addClass('select');
							var opcion=$(this).data('opcion');
							cont=1;
							$('.barra_content .seccion_inputs .seccion_icono').each(function(){
								if(opcion!=$(this).data('opcion') && $(this).data('opcion')!='atras'){
									$(this).addClass('sin_selec_'+cont);
									cont++;
								}
							});

							$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');
							var delay=setInterval(function(){
								clearInterval(delay);
								$('#barra_de_busqueda .seccion_content_funciones #seccion_funcion-'+opcion).removeClass('oculto');
							},1500);

						
					}
				}

			}

		}


	});


	$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .seccion_checkbox').click(function(){
		if($(this).hasClass('checked')){

			$(this).find('input').prop('checked',false);
			$(this).removeClass('checked');
		}else{
			$(this).find('input').prop('checked',true);
			$(this).addClass('checked');

		}

	});



	$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_btn_buscar #btn_buscar').click(function(){



		if($('#barra_de_busqueda').data('posicion')=='inferior'){

			var stateObj = { foo: "busqueda" };
			window.history.pushState(stateObj, null, '');

			fun_animacion_espacio_busqueda(GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].latitud,GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].longitud);

			var delay5=setInterval(function(){
				clearInterval(delay5);

				fun_get_avisos(true,true);

			},6000);



		}else{


				if(!GL_MAPA){

						if($(window).width()>800){

							//$('body').addClass('comp-carga');
						}
						//$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('centrado');		
						


						//calculamos el ancho para el mapa en toda la pantalla
						$('.contenedor_mapa').css('width',$(window).width()+'px');
						$('.contenedor_mapa').css('height',$(window).height()+'px');

						$('#content_lineas_dinamicas').addClass('oculto');

						//if(!GL_MAPA){

							fun_carga_google_maps(GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].latitud,GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].longitud);		

						//}else{

						//}


						$('#slider-portal').addClass('oculto');
						var delay_muestra_mapa=setInterval(function(){
							if(GL_MAPA){
								clearInterval(delay_muestra_mapa);

				  				$('.content_mapa_buscador').removeClass('oculto');
							}
						},500);

				}



					var consulta_avisos=setInterval(function(){
						if(GL_MAPA){
								clearInterval(consulta_avisos);
							fun_get_avisos(true,true,function(){



								$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');
									
								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('sin_selec_3');
								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('select');
									
								var delay=setInterval(function(){
									clearInterval(delay);
									$('#barra_de_busqueda .content_resultados_avisos').removeClass('oculto');


								},500);

							});
						}
					},500);

		}


	});


	$('#barra_de_busqueda .btn_ocultar_barra_busqueda').click(function(){
		if($('#barra_de_busqueda').hasClass('minimizado')){

			$('#barra_de_busqueda').removeClass('minimizado');
			$('.barra_content #seccion_inputs').removeClass('oculto_minimizado');
			$('.content_resultados_avisos').removeClass('oculto_minimizado');
			$('.seccion_content_funciones').removeClass('oculto_minimizado');

		}else{
			$('#barra_de_busqueda').addClass('minimizado');
			$('.barra_content #seccion_inputs').addClass('oculto_minimizado');
			$('.content_resultados_avisos').addClass('oculto_minimizado');
			$('.seccion_content_funciones').addClass('oculto_minimizado');
		}
		
	});


	$('body').on('click','#btn_ver_lugares_cercanos',function(){
		if($('.seccion_lugares_cercanos').hasClass('minimizado')){			
			$('.seccion_lugares_cercanos').removeClass('minimizado');
		}else{
			$('.seccion_lugares_cercanos').addClass('minimizado');
		}
	});


	$('body').on('click','#btn_buscar_lugares_cercanos',function(){


		clearInterval(GL_CONTEO_REGRESIVO_BUSQUEDA);
		$('#btn_buscar_lugares_cercanos .content_contador').removeClass('conteo');

		var tipos_lugares=new Array();

		$('#opciones_lugares_cercanos input').each(function(){
			if($(this).is(':checked')){
				tipos_lugares.push($(this).val());
			}
		});

		if(tipos_lugares.length==0){
			tipos_lugares=['bar'];
			$('#opciones_lugares_cercanos .check').first().click();
		}

		fun_mostrar_lugares_cerca(tipos_lugares);

	});

	$('body').on('click','#btn_borrar_lugares_cercanos',function(){

  		$('#btn_borrar_lugares_cercanos').addClass('oculto');
  		$('#opciones_lugares_cercanos .check').removeClass('checked');
		fun_limpiar_lugares_cerca();

	});
	$('body').on('click','#btn_borrar_avenidas_lugares',function(){


		fun_limpiar_markers_lugares();

	});


	$('#opciones_lugares_cercanos .check').click(function(){

		clearInterval(GL_INTERVAL_MENSAJE_SIN_RESULTADOS);
		$('#mensaje_busqueda_lugares').addClass('oculto');

		
		if($(this).hasClass('checked')){
			$(this).find('input').prop('checked',false);
			$(this).removeClass('checked');

		}else{
			$(this).find('input').prop('checked',true);
			$(this).addClass('checked');

			
		}


		if($('#opciones_lugares_cercanos .check.checked').length==0){
				clearInterval(GL_CONTEO_REGRESIVO_BUSQUEDA);
				$('#btn_buscar_lugares_cercanos .content_contador').removeClass('conteo');
				fun_limpiar_lugares_cerca();
			}else{

				$('#btn_buscar_lugares_cercanos .content_contador').addClass('conteo');
				$('#btn_buscar_lugares_cercanos .content_contador .contador').html('3');

				clearInterval(GL_CONTEO_REGRESIVO_BUSQUEDA);
				GL_CONTEO_REGRESIVO_BUSQUEDA=setInterval(function(){
					var cuenta=parseInt($('#btn_buscar_lugares_cercanos .content_contador .contador').html());
					if(cuenta>1 ){
						$('#btn_buscar_lugares_cercanos .content_contador .contador').html(cuenta-1);
					}else{						
						$('#btn_buscar_lugares_cercanos .content_contador .contador').html('0');
						clearInterval(GL_CONTEO_REGRESIVO_BUSQUEDA);
						$('#btn_buscar_lugares_cercanos').click();
					}

				},1000);
				
			}
	});



	$('.content_resultados_avisos').on('click','.resultado-aviso',function(){


		var id=$(this).data('id');
		
		if(id!= $('.resultado-aviso-content.seleccionado .resultado-aviso').data('id')){


			var stateObj = { foo: "anuncio" };
			window.history.pushState(stateObj, "", GL_DNS+'/anuncios/'+id+'_'+GL_AVISOS[id].id_text);


			if(GL_MAPA){
				fun_moveToLocation(GL_AVISOS[id].coor_latitud,GL_AVISOS[id].coor_longitud,-250,0);

				
			}


			fun_mostrar_info_aviso(id);
		}
	});



	$('#barra_de_busqueda .div_buscador ').on('click','#seccion_bus_ver_mas_opciones',function(){

		if($(this).data('opciones_extras')=='no'){
			$(this).data('opciones_extras','si');
			$('#seccion_bus_mas_opciones').slideDown(300);
			$(this).html('Ocultar opciones extras');
		}else{
			$(this).data('opciones_extras','no');
			$('#seccion_bus_mas_opciones').slideUp(300);
			$(this).html('Ver m&aacute;s opciones');

		}

	});








$('body').on('click','.div_anunciante .div_form_contacto #btn_enviar',function(){

		
      id_aviso=$(this).data('id');
      $('#resultado-aviso-'+id_aviso+' .div_anunciante .campo .msj_aux').addClass('oculto');

      $('#resultado-aviso-'+id_aviso+' .div_form_contacto #contact_aviso_nombre').parent().removeClass('alerta');
      $('#resultado-aviso-'+id_aviso+' .div_form_contacto #contact_aviso_correo').parent().removeClass('alerta');
      $('#resultado-aviso-'+id_aviso+' .div_form_contacto #contact_aviso_telefono').parent().removeClass('alerta');
      $('#resultado-aviso-'+id_aviso+' .div_form_contacto #contact_aviso_mensaje').parent().removeClass('alerta');
      

      content='#resultado-aviso-'+id_aviso+' .div_anunciante  .div_form_contacto ';

      nombre=((typeof $(content+'#contact_aviso_nombre').val() =='string')? $(content+'#contact_aviso_nombre').val() : 'no definido' );
      correo=((typeof $(content+'#contact_aviso_correo').val()=='string')? $(content+'#contact_aviso_correo').val() : 'no definido' );
      telefono=((typeof $(content+'#contact_aviso_telefono').val()=='string')? $(content+'#contact_aviso_telefono').val() : 'no definido' );
      mensaje=((typeof $(content+'#contact_aviso_mensaje').val()=='string')? $(content+'#contact_aviso_mensaje').val() : 'no definido' );


      if(!fun_esblanco(nombre) && !fun_esblanco(correo)  && !fun_esblanco(mensaje)){
        
        


        $.ajax({
              url: "POST/contacto_aviso.php",
              type: "POST",
              data:{id_aviso:id_aviso, nombre:fun_ignora_tildes($(content+'#contact_aviso_nombre').val()),correo:$(content+'#contact_aviso_correo').val(),telefono:$(content+'#contact_aviso_telefono').val(),mensaje:fun_ignora_tildes($(content+'#contact_aviso_mensaje').val()),aviso_id_img:GL_AVISOS[id_aviso].img_previa,aviso_ext_img:GL_AVISOS[id_aviso].img_previa_ext,aviso_titulo:GL_AVISOS[id_aviso].titulo,aviso_precio:GL_AVISOS[id_aviso].costo,aviso_direccion:GL_AVISOS[id_aviso].direccion,aviso_id_text:GL_AVISOS[id_aviso].id_text},
              async:true,
              beforeSend: function(objeto){
                
                $('#resultado-aviso-'+id_aviso+' #btn_enviar .content').html('Enviando...');
                $('#resultado-aviso-'+id_aviso+' #btn_enviar').parent().addClass('enviando');
              },
                
          success: function(data){
      
            if(data=="mysql_no"){
              FMSG_ERROR_CONEXION();
            }else{

            	$('.resultado-aviso-content .info-detalles-aviso .div_anunciante .div_form_contacto').addClass('oculto');

            	$('.resultado-aviso-content .info-detalles-aviso .div_anunciante .dif_form_contacto_contenedor .div_mensaje_icono').removeClass('oculto');

            	var delay_animacion=setInterval(function(){
            		clearInterval(delay_animacion);
            		$('.resultado-aviso-content .info-detalles-aviso .div_mensaje_icono').addClass('efecto_envio');

            		var delay_quita_animacion=setInterval(function(){
            			clearInterval(delay_quita_animacion);

            			$('.resultado-aviso-content .info-detalles-aviso .div_anunciante .div_form_contacto').removeClass('oculto');

            			$('.resultado-aviso-content .info-detalles-aviso .div_anunciante .dif_form_contacto_contenedor .div_mensaje_icono').addClass('oculto');


            			var delay_quita_animacion2=setInterval(function(){
            				clearInterval(delay_quita_animacion2);
            				$('.resultado-aviso-content .info-detalles-aviso .div_mensaje_icono').removeClass('efecto_envio');
            			},500);
            		},3000);

            	},500);
      

                $('#resultado-aviso-'+id_aviso+' #contact_aviso_nombre').val('');
                $('#resultado-aviso-'+id_aviso+' #contact_aviso_correo').val('');
                $('#resultado-aviso-'+id_aviso+' #contact_aviso_telefono').val('');
                $('#resultado-aviso-'+id_aviso+' #contact_aviso_mensaje').val('');
                          
                $('#resultado-aviso-'+id_aviso+' #contact_aviso_nombre').removeClass('alerta');
                $('#resultado-aviso-'+id_aviso+' #contact_aviso_correo').removeClass('alerta');
                $('#resultado-aviso-'+id_aviso+' #contact_aviso_mesaje').removeClass('alerta');
                  
                $('#resultado-aviso-'+id_aviso+' #btn_enviar .content').html('Mensaje enviado');

                var delay_envio=setInterval(function(){
                  clearInterval(delay_envio);
                  	$('#resultado-aviso-'+id_aviso+' #btn_enviar .content').html('Enviar');
                	$('#resultado-aviso-'+id_aviso+' #btn_enviar ').parent().removeClass('enviando');
                },4000);
            }
          }
                  
              
        }); 
        
        
      }else{

        if(fun_esblanco(nombre)){
          $('#resultado-aviso-'+id_aviso+' #contact_aviso_nombre').parent().addClass('alerta');
          $('#resultado-aviso-'+id_aviso+' #contact_aviso_nombre').next().removeClass('oculto');
        }
        if(fun_esblanco(correo)){
          $('#resultado-aviso-'+id_aviso+' #contact_aviso_correo').parent().addClass('alerta');
          $('#resultado-aviso-'+id_aviso+' #contact_aviso_correo').next().removeClass('oculto');
        }
        if(fun_esblanco(mensaje)){
          $('#resultado-aviso-'+id_aviso+' #contact_aviso_mensaje').parent().addClass('alerta');
          $('#resultado-aviso-'+id_aviso+' #contact_aviso_mensaje').next().removeClass('oculto');
        }  
            
      }
      
});





	$('.barra_content .seccion_inputs  #btn_atras').click(function(){
		//modificamos la barra superior mostrando el boton atras
		$(".barra_content .seccion_inputs  #btn_atras").addClass('oculto');
		//$(".barra_content .seccion_inputs  #btn_busqueda").removeClass('desp_x');

		$(".resultados_avisos").data('contenido','lista');

		$('.resultado-aviso-content.seleccionado').css("height","0px");
		var delay=setInterval(function(){
			clearInterval(delay);
			$('.content_resultados_avisos .resultados_avisos').html('');

			fun_imprimir_resultados();
		},600);
	});


	$('#avisos_inmovidi').click(function(){

		GL_AVISOS=new Array();

		GL_AVISOS[GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].id]=GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI];

		id_aviso=GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].id;


		fun_animacion_espacio_busqueda(GL_AVISOS[id_aviso].coor_latitud,GL_AVISOS[id_aviso].coor_longitud);

		var delay2=setInterval(function(){
			clearInterval(delay2);
			
			fun_imprimir_resultados();
		


			var delaymove=setInterval(function(){
				clearInterval(delaymove);

				fun_moveToLocation(GL_AVISOS[id_aviso].coor_latitud,GL_AVISOS[id_aviso].coor_longitud,-250,0);


				$('.content_resultados_avisos .resultado-aviso[data-id="'+id_aviso+'"]').click();

			},1500);


		},6000);



	});

});



var GL_NOTICIAS=new Array();




$(window).scroll(function(){

	var scroll_pagina=((document.body.scrollTop)? document.body.scrollTop :document.documentElement.scrollTop);
	var top_min=$('#portafolios').offset().top;
	var top_next=$('#informacion').offset().top;

	if(scroll_pagina>=top_next-$(window).height() && scroll_pagina>top_min){
		$('body').addClass('fondo_noche');
		$('#portafolios .visor_noticias').removeClass('fixed');	
		$('#portafolios .visor_noticias').addClass('absolute_bottom');	

		$('#portafolios .etiqueta_titulo').removeClass('fixed');	
		$('#portafolios .etiqueta_titulo').addClass('absolute_bottom');		

	}else{

		if(scroll_pagina>=top_min){
			$('#portafolios .visor_noticias').addClass('fixed');
			$('#portafolios .visor_noticias').removeClass('absolute_bottom');	

			$('#portafolios .etiqueta_titulo').addClass('fixed');
			$('#portafolios .etiqueta_titulo').removeClass('absolute_bottom');	
		}else{
			$('#portafolios .visor_noticias').removeClass('fixed');		

			$('#portafolios .etiqueta_titulo').removeClass('fixed');	
			$('body').removeClass('fondo_noche');	
		}
	}

});





function fun_mostrar_info_noticia(id){
	

	GL_POSICION_NAVEGACION_PAGINA='viendo_noticia';



	var stateObj = { foo: "noticia" };

	window.history.pushState(stateObj, "", GL_DNS+'/noticias/'+id+'_'+GL_NOTICIAS[id].id_titulo);

	


	$('#portafolios .comp-visor-fotos').addClass('mitad');
	$('#portafolios').addClass('fondo_movido');

		var delay=setInterval(function(){
			clearInterval(delay);

		$('.noticia_detalles .titulo_noticia').html(GL_NOTICIAS[id].titulo);
		$('.noticia_detalles .descripcion_noticia').html(GL_NOTICIAS[id].descripcion);


		$('.noticia_detalles .botones_sociales_noticia').html('<div class="fb-share-button " data-href="'+  GL_DNS+'/noticias/'+id+'_'+GL_NOTICIAS[id].id_titulo+'" data-layout="button_count" ></div> <a class="twitter-share-button"  href="'+  GL_DNS+'/noticias/'+id+'_'+GL_NOTICIAS[id].id_titulo+'"> Tweetear</a>');





	    html_fotos='';
	    cont_fotos=0;

	    for(var index in GL_NOTICIAS[id].fotos){
	   	cont_fotos++;
	    	html_fotos+='<foto data-src="IMG/NOTICIAS/FOTOS/WEB/'+GL_NOTICIAS[id].fotos[index].id_img+'.'+GL_NOTICIAS[id].fotos[index].ext_img+'" data-minisrc="IMG/NOTICIAS/FOTOS/MINI/'+GL_NOTICIAS[id].fotos[index].id_img+'.'+GL_NOTICIAS[id].fotos[index].ext_img+'" data-msrc="IMG/NOTICIAS/FOTOS/MOVIL/'+GL_NOTICIAS[id].fotos[index].id_img+'.'+GL_NOTICIAS[id].fotos[index].ext_img+'" data-tipotexto="texto_dividido" data-titulo="" data-descripcion=""></foto>';
	    }

	    if(cont_fotos>0){

	    	$('#content_visor_detalles_portafolios .fotos_noticia').show();
			$('#content_visor_detalles_portafolios .fotos_noticia').html('<div class="comp-visor-fotos" data-inicializado="false" data-tipo="barra-inferior" data-botones="true" data-getbd="false" data-iniciar="true">'+html_fotos+'</div>');



			GL_COMPONENTE_VISOR_FOTOS.ini();
			GL_COMPONENTE_CARGANDO.cargar_msrc();
			GL_COMPONENTE_CARGANDO.asignar_fondos_css_img();

			$('#content_visor_detalles_portafolios .fotos_noticia .comp-visor-fotoprev:first-child').click();

	    }else{

	    	$('#content_visor_detalles_portafolios .fotos_noticia').hide();
	    	$('#content_visor_detalles_portafolios .fotos_noticia').html('<div class="comp-visor-fotos" data-inicializado="false" data-tipo="barra-inferior" data-botones="true" data-getbd="false" data-iniciar="true"></div>');
	    }

		$('#content_visor_detalles_portafolios .comentarios_noticia').html('<div class="fb-comments" data-width="100%" data-href="'+GL_DNS+'/noticias/'+id+'_'+GL_NOTICIAS[id].id_titulo+'" data-numposts="5" ></div>');



		FB.XFBML.parse(document.getElementById('visor_portafolios'));
		twttr.widgets.load();

		$('#portafolios #content_visor_detalles_portafolios').removeClass('oculto');


	},500);




/*	GL_POSICION_NAVEGACION_PAGINA='viendo_noticia';




	if(!relacionada){

		var stateObj = { foo: "noticia" };

		window.history.pushState(stateObj, "", GL_DNS+'/noticias/'+id+'_'+GL_NOTICIAS[id].id_titulo);

	}

	$('.noticia_detalles .img_noticia').css('background-image','url(IMG/NOTICIAS/FONDOS/WEB/'+GL_NOTICIAS[id].id_img+'.'+GL_NOTICIAS[id].ext_img+')');
	
	//$('.noticia_detalles .fotos_noticia').html(GL_NOTICIAS[id].descripcion);


	$('.noticia_detalles .botones_sociales_noticia').html('<div class="fb-share-button " data-href="'+  GL_DNS+'/noticias/'+id+'_'+GL_NOTICIAS[id].id_titulo+'" data-layout="button_count" ></div> <a class="twitter-share-button"  href="'+  GL_DNS+'/noticias/'+id+'_'+GL_NOTICIAS[id].id_titulo+'"> Tweetear</a>');





    html_fotos='';
    cont_fotos=0;

    for(var index in GL_NOTICIAS[id].fotos){
   	cont_fotos++;
    	html_fotos+='<foto data-src="IMG/NOTICIAS/FOTOS/WEB/'+GL_NOTICIAS[id].fotos[index].id_img+'.'+GL_NOTICIAS[id].fotos[index].ext_img+'" data-minisrc="IMG/NOTICIAS/FOTOS/MINI/'+GL_NOTICIAS[id].fotos[index].id_img+'.'+GL_NOTICIAS[id].fotos[index].ext_img+'" data-msrc="IMG/NOTICIAS/FOTOS/MOVIL/'+GL_NOTICIAS[id].fotos[index].id_img+'.'+GL_NOTICIAS[id].fotos[index].ext_img+'" data-tipotexto="texto_dividido" data-titulo="" data-descripcion=""></foto>';
    }




    if(cont_fotos>0){

    	$('#content_visor_detalles_portafolios .fotos_noticia').show();
		$('#content_visor_detalles_portafolios .fotos_noticia').html('<div class="comp-visor-fotos" data-inicializado="false" data-tipo="barra-inferior" data-botones="true" data-getbd="false" data-iniciar="true">'+html_fotos+'</div>');



		GL_COMPONENTE_VISOR_FOTOS.ini();
		GL_COMPONENTE_CARGANDO.cargar_msrc();
		GL_COMPONENTE_CARGANDO.asignar_fondos_css_img();

		$('#content_visor_detalles_portafolios .fotos_noticia .comp-visor-fotoprev:first-child').click();

    }else{

    	$('#content_visor_detalles_portafolios .fotos_noticia').hide();
    	$('#content_visor_detalles_portafolios .fotos_noticia').html('<div class="comp-visor-fotos" data-inicializado="false" data-tipo="barra-inferior" data-botones="true" data-getbd="false" data-iniciar="true"></div>');
    }

	$('#content_visor_detalles_portafolios .comentarios_noticia').html('<div class="fb-comments" data-width="100%" data-href="'+GL_DNS+'/noticias/'+id+'_'+GL_NOTICIAS[id].id_titulo+'" data-numposts="5" ></div>');



		FB.XFBML.parse(document.getElementById('visor_portafolios'));
		twttr.widgets.load();






	$('#content_visor_detalles_portafolios ').removeClass('oculto');
	$('body').addClass('sin_scroll');*/
}

function fun_ocultar_visor_portafolios(){

	$('#content_visor_detalles_portafolios').addClass('oculto');

}








function fun_mostrar_info_aviso(id_aviso){


    var html_fotos='';
    if(GL_AVISOS[id_aviso].fotos.length>0){

	    for(var index in GL_AVISOS[id_aviso].fotos){

	    	html_fotos+='<foto data-src="IMG/AVISOS/FOTOS/WEB/'+GL_AVISOS[id_aviso].fotos[index].id_img_foto+'.'+GL_AVISOS[id_aviso].fotos[index].ext_img_foto+'" data-minisrc="IMG/AVISOS/FOTOS/MINI/'+GL_AVISOS[id_aviso].fotos[index].id_img_foto+'.'+GL_AVISOS[id_aviso].fotos[index].ext_img_foto+'" data-msrc="IMG/AVISOS/FOTOS/MOVIL/'+GL_AVISOS[id_aviso].fotos[index].id_img_foto+'.'+GL_AVISOS[id_aviso].fotos[index].ext_img_foto+'" data-tipotexto="texto_dividido" data-titulo="" data-descripcion=""></foto>';

	    }

	    	html_visor_fotos='<div class="comp-visor-fotos" data-inicializado="false" data-tipo="barra-inferior" data-botones="true" data-getbd="false" data-iniciar="true">'+   		
	    		html_fotos+
	    	'</div>';


	    $('#resultado-aviso-'+id_aviso+' .div_fotos').html(html_visor_fotos);

	    var delay_fotos=setInterval(function(){
	    	clearInterval(delay_fotos);
			GL_COMPONENTE_VISOR_FOTOS.ini();
	    },1000);

    }



    $('#resultado-aviso-'+id_aviso+' .btns_fb').html('<div class="fb-share-button " data-href="'+ GL_DNS+'/anuncios/'+GL_AVISOS[id_aviso].id+'_'+GL_AVISOS[id_aviso].id_text+'" data-layout="button_count" ></div> <a class="twitter-share-button"  href="'+ GL_DNS+'/anuncios/'+GL_AVISOS[id_aviso].id+'_'+GL_AVISOS[id_aviso].id_text+'"> Tweetear</a> ');

	FB.XFBML.parse(document.getElementById('resultado-aviso-'+id_aviso));
	twttr.widgets.load();





	//modificamos la barra superior mostrando el boton atras
	$(".barra_content .seccion_inputs  #btn_atras").removeClass('oculto');
	//$(".barra_content .seccion_inputs  #btn_busqueda").addClass('desp_x');

	$(".resultados_avisos").data('contenido','detalle');

	fun_aumentar_visita(id_aviso);


	$('.resultado-mostrado-aviso').each(function(){
		id=$(this).data('id');
		if(id_aviso!=id){
			$(this).parent().addClass('oculto');
			$(this).parent().removeClass('seleccionado');
		}else{
			obj=$(this);
			var delay_selec=setInterval(function(){
				clearInterval(delay_selec);
				$(obj).parent().removeClass('oculto');
				$(obj).parent().addClass('seleccionado');

				var delay_oculto=setInterval(function(){
					clearInterval(delay_oculto);
					$('.resultados_avisos #resultado-aviso-'+id_aviso+' .info-detalles-aviso .div-img-previa').removeClass('oculto');

					altura_img=200;
					altura_content=$('#barra_de_busqueda .content_resultados_avisos').css('height').replace('px','');
					altura_info=altura_content-altura_img;
					
					$('.resultados_avisos #resultado-aviso-'+id_aviso+' .info-detalles-aviso .div-info-aviso').css('height',altura_info+'px');

					$('.resultados_avisos #resultado-aviso-'+id_aviso+'  .comp-visor-fotoprev:first-child').click();

				},1000);
			},500);			
		}
			$(this).parent().addClass('top_0');

	});
}





































function fun_moveToLocation(lat, lng, desp_x , desp_y){
    var center = new google.maps.LatLng(lat, lng);
    // using global variable:

    var projection = new MercatorProjection();
  	var worldCoordinate = projection.fromLatLngToPoint(center);


  	var numTiles = 1 << GL_MAPA.getZoom();

  	 var pixelCoordinate = new google.maps.Point(
      worldCoordinate.x * numTiles,
      worldCoordinate.y * numTiles);

    
  	 var nuevo_punto = new google.maps.Point(
      (pixelCoordinate.x + desp_x)/numTiles ,
      (pixelCoordinate.y + desp_y)/numTiles );


  	var nuevo_centro_coordenadas = projection.fromPointToLatLng(nuevo_punto);

    GL_MAPA.panTo(nuevo_centro_coordenadas);
}




function fun_resize(){
	
	width_logo=120;
		/*$('#barra_de_busqueda').removeClass('responsive_w830');
		$('#barra_de_busqueda').removeClass('responsive_w955');
		$('#barra_de_busqueda').removeClass('responsive_w1120');
		$('#barra_de_busqueda').removeClass('responsive_w1210');
*/

	if($(window).width()<=800){			
		if(!GL_RESPONSIVE_BARRA_VERTICAL){
				fun_ajusta_barra_vertical_responsive();
			
		}
	}else{
		if(GL_RESPONSIVE_BARRA_VERTICAL){
				fun_animacion_ocultar_espacio_busqueda(false);
				

				
		}
	}

	$('.contenedor_mapa').css('width',$(window).width()+'px');
	$('.contenedor_mapa').css('height',$(window).height()+'px');


	if($('#barra_de_busqueda').data('posicion')=='inferior'){
	
		//$('.barra_content .seccion_inputs').css('width',($(window).width()-width_logo - 10)+'px');
		/*width_content_funciones=$(window).width()-width_logo-330;
		$('#barra_de_busqueda .seccion_content_funciones').css('width',(width_content_funciones)+'px');
		*/
		width_buscador=$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_borde_buscador').css('width');
		$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_borde_buscador').css('width',width_buscador);
	}


	$('#barra_de_busqueda .content_resultados_avisos').css('height',($(window).height()-70)+'px')
}





// The following example creates complex markers to indicate beaches near
// Sydney, NSW, Australia. Note that the anchor is set to
// (0,32) to correspond to the base of the flagpole.
var GL_MAPA;

  // Create the search box and link it to the UI element.
  

var GL_INFO_WINDOW_LUGAR;
  var GL_MARKERS_LUGARES= [];

function fun_carga_google_maps(latitud,longitud) {


  var mapOptions = {
    center: new google.maps.LatLng(latitud, longitud),
    zoom: 13
  }
   GL_MAPA= new google.maps.Map(document.getElementById('mapa_buscador'),
                                mapOptions);


	google.maps.event.addListener(GL_MAPA, "rightclick",function(event){fun_showContextMenu(event.latLng);});


	google.maps.event.addListener(GL_MAPA, "mouseup",function(event){

        $('.contextmenu').slideUp(300);
	});





  GL_INFO_WINDOW_LUGAR = new google.maps.InfoWindow();

var buscador_lugares = /** @type {HTMLInputElement} */(
      document.getElementById('pac-input'));


	var marker_lugar; 

  GL_MAPA.controls[google.maps.ControlPosition.TOP_LEFT].push(buscador_lugares);

  var searchBox = new google.maps.places.SearchBox(
    /** @type {HTMLInputElement} */(buscador_lugares));

  // Listen for the event fired when the user selects an item from the
  // pick list. Retrieve the matching places for that item.
  google.maps.event.addListener(searchBox, 'places_changed', function() {
    var places = searchBox.getPlaces();

    if (places.length == 0) {
      return;
    }
    fun_limpiar_markers_lugares();
    /*
    for (var i = 0, marker_lugar; marker_lugar = GL_MARKERS_LUGARES[i]; i++) {
      marker_lugar.setMap(null);
    }*/

    // For each place, get the icon, place name, and location.
    GL_MARKERS_LUGARES = [];
    var bounds = new google.maps.LatLngBounds();
    for (var i = 0, place; place = places[i]; i++) {
 
  // 	if(places[0]){

 		//place = places[0];
		// Create a marker for each place.
		
		fun_set_lugar_buscador(place);

		//var extendPoint = new google.maps.LatLng(bounds.getNorthEast().lat() + 0.01, bounds.getNorthEast().lng() + 0.01);

		bounds.extend(place.geometry.location);	

   	}
   // }

	    GL_MAPA.fitBounds(bounds);
	    GL_MAPA.setZoom(13);


  });


	// Bias the SearchBox results towards places that are within the bounds of the
	// current map's viewport.
	google.maps.event.addListener(GL_MAPA, 'bounds_changed', function() {
		var bounds = GL_MAPA.getBounds();
		searchBox.setBounds(bounds);

	});

  //setMarkers(GL_MAPA, GL_AVISOS);

}

function fun_limpiar_markers_lugares(){

    for (var i = 0, marker_lugar; marker_lugar = GL_MARKERS_LUGARES[i]; i++) {
      marker_lugar.setMap(null);
    }
}

function fun_set_lugar_buscador(place){

	var image='IMG/place.png';
	 var marker_lugar = new google.maps.Marker({
			map: GL_MAPA,
			icon: image,
			draggable:false,
			title: place.name,
			position: place.geometry.location,
			icon: image, animation: google.maps.Animation.DROP
		});

		GL_MARKERS_LUGARES.push(marker_lugar);

	  google.maps.event.addListener(marker_lugar, 'click', function() {
	    GL_INFO_WINDOW_LUGAR.setContent(place.name);
	    GL_INFO_WINDOW_LUGAR.open(GL_MAPA, this);
	  });
	  
}

function fun_getCanvasXY(caurrentLatLng){
      var scale = Math.pow(2, GL_MAPA.getZoom());
     var nw = new google.maps.LatLng(
         GL_MAPA.getBounds().getNorthEast().lat(),
         GL_MAPA.getBounds().getSouthWest().lng()
     );
     var worldCoordinateNW = GL_MAPA.getProjection().fromLatLngToPoint(nw);
     var worldCoordinate = GL_MAPA.getProjection().fromLatLngToPoint(caurrentLatLng);
     var caurrentLatLngOffset = new google.maps.Point(
         Math.floor((worldCoordinate.x - worldCoordinateNW.x) * scale),
         Math.floor((worldCoordinate.y - worldCoordinateNW.y) * scale)
     );
     return caurrentLatLngOffset;
  }
  function fun_setMenuXY(caurrentLatLng){
    var mapWidth = $('#mapa_buscador').width();
    var mapHeight = $('#mapa_buscador').height();
    var menuWidth = $('.contextmenu').width();
    var menuHeight = $('.contextmenu').height();
    var clickedPosition = fun_getCanvasXY(caurrentLatLng);
    var x = clickedPosition.x ;
    var y = clickedPosition.y ;

     if((mapWidth - x ) < menuWidth)
         x = x - menuWidth;
    if((mapHeight - y ) < menuHeight)
        y = y - menuHeight;

    $('.contextmenu').css('left',x  );
    $('.contextmenu').css('top',y );
    };



  function fun_showContextMenu(caurrentLatLng) {
        var projection;
        var contextmenuDir;
        projection = GL_MAPA.getProjection() ;
        $('.contextmenu').remove();

        $(GL_MAPA.getDiv()).append('<div class="contextmenu"></div>');

        $('.contextmenu').html("<a id='menu1' data-lat='"+caurrentLatLng.lat()+"' data-lng='"+caurrentLatLng.lng()+"'><div class='context'>Buscar aqu&iacute;</div></a><a id='menu2'><div class='context'>¿Qu&eacute; hay cerca?</div></a>"); 
        
        fun_setMenuXY(caurrentLatLng);

        $('.contextmenu').slideDown(300);

       }


$(document).ready(function(){
	$('body').on('click','.contextmenu #menu1',function(){
        $('.contextmenu').slideUp(300);
		var lat=$(this).data('lat');
		var lng=$(this).data('lng');
		
		var center = new google.maps.LatLng(lat, lng);

		GL_CIRCULO_BUSQUEDA.setCenter(center);
	});

	$('body').on('click','.contextmenu #menu2',function(){
        $('.contextmenu').slideUp(300);
        $('#btn_ver_lugares_cercanos').click();
	});
});
















/**
 * Data for the markers consisting of a name, a LatLng and a zIndex for
 * the order in which these markers should display on top of each
 * other.
 */

var GL_ARRAY_MAKERS=new Array();
var GL_MAP_AVISOS_MARKERS=[];
function setMarkers(map, locations) {
  // Add markers to the map

  // Marker sizes are expressed as a Size of X,Y
  // where the origin of the image (0,0) is located
  // in the top left of the image.

  // Origins, anchor positions and coordinates of the marker
  // increase in the X direction to the right and in
  // the Y direction down.

  var image;

  switch(parseInt($('.div_buscador #inmueble').val())){
  	case 1:
  		image= 'IMG/INICIO/SENALADORES/departamento.png';
  	break;
  	case 2:
  		image= 'IMG/INICIO/SENALADORES/minidepa.png';
  	break;
  	case 3:
  		image= 'IMG/INICIO/SENALADORES/casa.png';
  	break;
  	case 4:
  		image= 'IMG/INICIO/SENALADORES/habitacion.png';
  	break;
  	case 5:
  		image= 'IMG/INICIO/SENALADORES/oficina.png';
  	break;
  	case 6:
  		image= 'IMG/INICIO/SENALADORES/local.png';
  	break;
  	case 7:
  		image= 'IMG/INICIO/SENALADORES/terreno.png';
  	break;
  }
  

  /*{
    url: 'IMG/point.png',
    // This marker is 20 pixels wide by 32 pixels tall.
    size: new google.maps.Size(20, 32),
    // The origin for this image is 0,0.
    origin: new google.maps.Point(0,0),
    // The anchor for this image is the base of the flagpole at 0,32.
    anchor: new google.maps.Point(0, 32)
  };*/
  // Shapes define the clickable region of the icon.
  // The type defines an HTML &lt;area&gt; element 'poly' which
  // traces out a polygon as a series of X,Y points. The final
  // coordinate closes the poly by connecting to the first
  // coordinate.
  /*var shape = {
      coords: [1, 1, 1, 20, 18, 20, 18 , 1],
      type: 'poly'
  };*/


  var bounds = new google.maps.LatLngBounds();



for (var i = 0, marker; marker = GL_MAP_AVISOS_MARKERS[i]; i++) {
      marker.setMap(null);
    }

    // For each place, get the icon, place name, and location.
    GL_MAP_AVISOS_MARKERS = [];


  for (var index in locations) {

    var beach = locations[index];
 

     var marker = new google.maps.Marker({
        position: new google.maps.LatLng(beach.coor_latitud, beach.coor_longitud),
        map: map,
        icon: image,
        animation: google.maps.Animation.DROP,
        //shape: shape,
        title: beach.titulo,
        indice: parseInt(beach.id)
    });


    fun_set_event(marker);

     GL_MAP_AVISOS_MARKERS.push(marker);


    //bounds.extend(marker.position);
  /*   google.maps.event.addListener(GL_ARRAY_MAKERS[index], 'click', function() { 

       $('.content_resultados_avisos #resultado-aviso-'+GL_ARRAY_MAKERS[index].indice).click();
    }); */


  }

  //map.fitBounds(bounds);

}
function fun_set_event(marker) {
  	google.maps.event.addListener(marker, 'click', function() {
    // do something with this marker ...\



 		if($('#barra_de_busqueda .content_resultados_avisos').hasClass('oculto')){
 			//con esto verificamos si el contenedor de resultados est'a oculto

			$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');						
			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('sin_selec_3');
			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('select');

			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').addClass('sin_selec_1');
			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').removeClass('select');
			var delay=setInterval(function(){
				clearInterval(delay);
				$('#barra_de_busqueda .content_resultados_avisos').removeClass('oculto');
			},500);

 		}


       $('.content_resultados_avisos #resultado-aviso-'+marker.indice).click();
	    
	  });
}



/*
function initialize_map(locations) {
  var options = {
    zoom: 8,
    center: new google.maps.LatLng(59.933688,30.331879),
    mapTypeId: google.maps.MapTypeId.ROADMAP
  }
  var map = new google.maps.Map(document.getElementById("map-canvas"), options);
  var bounds = new google.maps.LatLngBounds();
  for (i = 0; i < locations.length; i++) {
    marker = new google.maps.Marker({
      position: new google.maps.LatLng(locations[i][lat], locations[i][lng]),
      map: map,
      title: locations[i][title]
    });
    bounds.extend(marker.position);
  }
  map.fitBounds(bounds);
}

*/




var GL_DISTRITOS=new Array();
GL_DISTRITOS[49]={latitud:-11.7725870000,longitud:-77.1553190000};
GL_DISTRITOS[50]={latitud:-12.0215240000,longitud:-76.8662420000};
GL_DISTRITOS[51]={latitud:-12.1416690000,longitud:-77.0163980000};
GL_DISTRITOS[52]={latitud:-12.0582390000,longitud:-77.1056040000};
GL_DISTRITOS[53]={latitud:-12.0610190000,longitud:-77.0486280000};
GL_DISTRITOS[54]={latitud:-11.8492070000,longitud:-77.0306930000};
GL_DISTRITOS[55]={latitud:-12.0335280000,longitud:-77.1316760000};
GL_DISTRITOS[56]={latitud:-12.0475470000,longitud:-77.0643120000};
GL_DISTRITOS[57]={latitud:-11.9844160000,longitud:-76.7704280000};
GL_DISTRITOS[58]={latitud:-12.1858030000,longitud:-77.0223210000};
GL_DISTRITOS[59]={latitud:-12.0399500000,longitud:-77.0954490000};
GL_DISTRITOS[60]={latitud:-11.9331960000,longitud:-77.0672530000};
GL_DISTRITOS[61]={latitud:-12.0346200000,longitud:-76.9925580000};
GL_DISTRITOS[62]={latitud:-11.9915530000,longitud:-77.0512520000};
GL_DISTRITOS[63]={latitud:-12.0779730000,longitud:-77.0483700000};
GL_DISTRITOS[64]={latitud:-12.0714270000,longitud:-77.1628010000};
GL_DISTRITOS[65]={latitud:-12.0828410000,longitud:-77.0369120000};
GL_DISTRITOS[66]={latitud:-12.0024470000,longitud:-76.9174280000};
GL_DISTRITOS[67]={latitud:-12.2732510000,longitud:-76.8705060000};
GL_DISTRITOS[68]={latitud:-12.1173760000,longitud:-77.0394210000};
GL_DISTRITOS[69]={latitud:-12.0957240000,longitud:-77.0642920000};
GL_DISTRITOS[70]={latitud:-12.0786030000,longitud:-76.9137650000};
GL_DISTRITOS[71]={latitud:-11.9709820000,longitud:-77.0730670000};
GL_DISTRITOS[72]={latitud:-12.2301380000,longitud:-76.8601930000};
GL_DISTRITOS[73]={latitud:-12.0704620000,longitud:-77.0630900000};
GL_DISTRITOS[74]={latitud:-12.0703780000,longitud:-77.1172070000};
GL_DISTRITOS[75]={latitud:-11.8670990000,longitud:-77.0774080000};
GL_DISTRITOS[76]={latitud:-12.4639830000,longitud:-76.7699790000};
GL_DISTRITOS[77]={latitud:-12.3138400000,longitud:-76.8014070000};
GL_DISTRITOS[78]={latitud:-12.3654900000,longitud:-76.7911080000};
GL_DISTRITOS[79]={latitud:-12.0352910000,longitud:-77.0278140000};
GL_DISTRITOS[80]={latitud:-12.4144480000,longitud:-76.7642480000};
GL_DISTRITOS[81]={latitud:-12.3876230000,longitud:-76.7683950000};
GL_DISTRITOS[82]={latitud:-12.1008440000,longitud:-76.9946040000};
GL_DISTRITOS[83]={latitud:-12.1886970000,longitud:-77.0128760000};
GL_DISTRITOS[84]={latitud:-11.8077070000,longitud:-77.1645620000};
GL_DISTRITOS[85]={latitud:-12.0992490000,longitud:-77.0352020000};
GL_DISTRITOS[86]={latitud:-12.0285760000,longitud:-77.0100940000};
GL_DISTRITOS[87]={latitud:-12.1507730000,longitud:-76.9740450000};
GL_DISTRITOS[88]={latitud:-12.0754560000,longitud:-76.9953270000};
GL_DISTRITOS[89]={latitud:-12.0773440000,longitud:-77.0920220000};
GL_DISTRITOS[90]={latitud:-11.9934840000,longitud:-77.0962410000};
GL_DISTRITOS[91]={latitud:-12.1497670000,longitud:-77.0107810000};
GL_DISTRITOS[92]={latitud:-12.1162010000,longitud:-77.0193230000};
GL_DISTRITOS[93]={latitud:-11.8878450000,longitud:-77.1268240000};
GL_DISTRITOS[94]={latitud:-12.0676920000,longitud:-77.0170060000};
GL_DISTRITOS[95]={latitud:-12.1591640000,longitud:-76.9287260000};
GL_DISTRITOS[96]={latitud:-12.2064820000,longitud:-76.9535910000};



var GL_AVISOS = new Array();
var GL_CONT_AVISOS=0;

var GL_CIRCULO_BUSQUEDA;
var GL_CENTRO_CIRCULO_CAMBIADO=false;
function fun_get_avisos(nueva_consulta,nuevo_circulo,f){


	if($('#seccion_funcion-buscar #distrito').val()=='pos_actual'){

		latitud=GL_CIRCULO_BUSQUEDA.getCenter().lat();
		longitud=GL_CIRCULO_BUSQUEDA.getCenter().lng();

	}else{

		latitud=GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].latitud;
		longitud=GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].longitud;

	}

	if(GL_CIRCULO_BUSQUEDA){
		distancia=GL_CIRCULO_BUSQUEDA.getRadius();
	}else{
		distancia=2000;
	}



costo_inicial=$('#seccion_funcion-buscar #costo_min').val(); 
costo_final=$('#seccion_funcion-buscar #costo_max').val(); 
	
if ( $.trim( costo_inicial ) == '' ){

	costo_inicial=0;
}

if ( $.trim( costo_final ) == '' ){

	costo_final=0;
}



var check_json='';

var checks_busqueda=new Array();

$('#seccion_bus_mas_opciones input[type="checkbox"]').each(function(){


	if($(this).is(':checked')){
		checks_busqueda[$(this).data('campo')]=true;

		if(check_json==''){
			check_json+='"'+$(this).data('campo')+'"';

		}else{

			check_json+=',"'+$(this).data('campo')+'"';

		}	
	}

})

if(check_json!=''){
	check_json='['+check_json+']';
}

var moneda=$('.div_buscador #moneda').val();

	$('#seccion_costo_inicial').removeClass('alerta');
	$('#seccion_costo_final').removeClass('alerta');

	$.ajax({
        url: "POST/get_avisos.php",
        type: "POST",
        datatype:'json',
        data:{transaccion:$('#seccion_funcion-buscar #transaccion').val(),tipo:$('#seccion_funcion-buscar #inmueble').val(),latitud:latitud, longitud: longitud,moneda:moneda, costo_inicial:costo_inicial,costo_final:costo_final,distancia:distancia,datos_extra:check_json},
        async:true,
        beforeSend: function(objeto){        	
        },	        
		success: function(data){
			

			if(data=="mysql_no"){
				FMSG_ERROR_CONEXION();
			}else{

				if(data=="error_costo_inicial" || data=="error_costo_final"){
					if(data=="error_costo_inicial"){


					$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_btn_buscar .mensaje_error_busqueda').removeClass('oculto');
						var delay_mensaje=setInterval(function(){
							clearInterval(delay_mensaje);

							$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_btn_buscar .mensaje_error_busqueda').addClass('oculto');

						},3000);
						$('#seccion_costo_inicial').addClass('alerta');
					}
					if(data=="error_costo_final"){

					$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_btn_buscar .mensaje_error_busqueda').removeClass('oculto');
						var delay_mensaje=setInterval(function(){
							clearInterval(delay_mensaje);

							$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_btn_buscar .mensaje_error_busqueda').addClass('oculto');

						},3000);
						$('#seccion_costo_final').addClass('alerta');
					}
				}else{
					if(typeof f=="function"){
						f();
					}

					if(nueva_consulta){
						GL_AVISOS=new Array();
					}

					if(data!='no data'){

						respuesta=$.parseJSON(data);


						for(var index in respuesta){

							GL_AVISOS[respuesta[index].id]=respuesta[index];
	/*
							GL_USUARIOS[respuesta[index].username]=respuesta[index];
							html_usuario=objeto.get_html_usuario(respuesta[index]);	*/						
						}

					

					}else{



					}


					//if(!GL_CIRCULO_BUSQUEDA || nuevo_circulo){
					if(!GL_CIRCULO_BUSQUEDA ){

						var circulo = {
						      strokeColor: 'rgb(20, 22, 204)',
						      strokeOpacity: 0.7,
						      strokeWeight: 2,
						      fillColor: 'rgb(20, 70, 204)',
						      fillOpacity: 0.4,
						      map: GL_MAPA,
						      draggable:false,
						      editable:true,
						      center: new google.maps.LatLng(GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].latitud, GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].longitud),
						      radius: 2000
						    };
						    // Add the circle for this city to the map.

						    if(GL_CIRCULO_BUSQUEDA){
						   		GL_CIRCULO_BUSQUEDA.setMap(null);
						    }

						    GL_CIRCULO_BUSQUEDA = new google.maps.Circle(circulo);


					 		google.maps.event.addListener(GL_CIRCULO_BUSQUEDA, 'center_changed', function(){


					 		$('#distrito option[value="pos_actual"]').remove();
					 		$('#distrito').prepend('<option value="pos_actual">Posici&oacute;n actual</option>');
					 		$('#distrito').val('pos_actual');

					 		if($('#barra_de_busqueda .content_resultados_avisos').hasClass('oculto')){
					 			//con esto verificamos si el contenedor de resultados est'a oculto

								$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');						
								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('sin_selec_3');
								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('select');

								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').addClass('sin_selec_1');
								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').removeClass('select');
								var delay=setInterval(function(){
									clearInterval(delay);
									$('#barra_de_busqueda .content_resultados_avisos').removeClass('oculto');
								},500);

					 		}

						 	fun_get_avisos(true,false);
					 		
					    });

					 	google.maps.event.addListener(GL_CIRCULO_BUSQUEDA, 'radius_changed', function(){

					 		if(GL_CIRCULO_BUSQUEDA.getRadius()>3000){
					 			GL_CIRCULO_BUSQUEDA.setRadius(3000);
					 		}else{

						 		if(GL_CIRCULO_BUSQUEDA.getRadius()<200){

					 				GL_CIRCULO_BUSQUEDA.setRadius(200);

						 		}
					 		}
/*
					 		if($('#barra_de_busqueda .content_resultados_avisos').hasClass('oculto')){
					 			//con esto verificamos si el contenedor de resultados est'a oculto

								$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');						
								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('sin_selec_3');
								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('select');

								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').addClass('sin_selec_1');
								$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').removeClass('select');
								var delay=setInterval(function(){
									clearInterval(delay);
									$('#barra_de_busqueda .content_resultados_avisos').removeClass('oculto');
								},500);

					 		}*/
					 		fun_get_avisos(true,false);
					 		

						 	//fun_get_avisos(GL_CIRCULO_BUSQUEDA.getCenter().lat(),GL_CIRCULO_BUSQUEDA.getCenter().lng(),false);
					 		
					    });

					}




					if($('.barra_content .seccion_inputs  #btn_atras').hasClass('oculto')){
						fun_imprimir_resultados(checks_busqueda);
					}else{
						$('.barra_content .seccion_inputs  #btn_atras').click();
					}

					 


				if($('#seccion_funcion-buscar #distrito').val()!='pos_actual'){

					var delay=setInterval(function(){

						if(GL_MAPA){
							
						clearInterval(delay);
							fun_moveToLocation(GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].latitud,GL_DISTRITOS[$('#seccion_funcion-buscar #distrito').val()].longitud,-250,0);

							
						}
					},1000);

				}
				}
			}
		}

	});
}


function fun_get_aviso_url(id_aviso){


	$.ajax({
        url: "POST/get_aviso_url.php",
        type: "POST",
        datatype:'json',
        data:{id:id_aviso},
        async:true,
        beforeSend: function(objeto){
        	
        },	        
		success: function(data){


			if(data=="mysql_no"){
				FMSG_ERROR_CONEXION();
			}else{

				if(data!='no data'){

					respuesta=$.parseJSON(data);
					GL_AVISOS=new Array();
					var GL_CONT_AVISOS=0;
					for(var index in respuesta){
						GL_AVISOS[respuesta[index].id]=respuesta[index];
/*
						GL_USUARIOS[respuesta[index].username]=respuesta[index];
						html_usuario=objeto.get_html_usuario(respuesta[index]);	*/						
					}

					fun_imprimir_resultados();
				



					
				}

				var delaymove=setInterval(function(){
					clearInterval(delaymove);

					fun_moveToLocation(GL_AVISOS[id_aviso].coor_latitud,GL_AVISOS[id_aviso].coor_longitud,-250,0);
					$('.content_resultados_avisos .resultado-aviso[data-id="'+id_aviso+'"]').click();


				},500);


					

			}
		}

	});
}

var GL_AVISOS_INMOVIDI = new Array();
var GL_CONT_AVISOS_INMOVIDI=0;

function fun_get_avisos_inmovidi(){

	$.ajax({
        url: "POST/get_avisos_inmovidi.php",
        type: "POST",
        datatype:'json',
        data:{},
        async:true,
        beforeSend: function(objeto){        	
        },	        
		success: function(data){
		
			if(data=="mysql_no"){
				FMSG_ERROR_CONEXION();
			}else{

				if(data!='no data'){

					respuesta=$.parseJSON(data);
					var cont=0;
					for(var index in respuesta){
						GL_AVISOS_INMOVIDI[cont]=respuesta[index];	
						cont++;			
					}

					fun_rotar_avisos_inmovidi();
		
				}
			}
		}
	});
}

var GL_INDICE_ROTADOR_INMOVIDI=-1;

function fun_rotar_avisos_inmovidi(){

	var delay_inicial=setInterval(function(){

		clearInterval(delay_inicial);

		$('#avisos_inmovidi .div-der .titulo').addClass('oculto');

		var _delay_1 =setInterval(function(){
			clearInterval(_delay_1);
			$('#avisos_inmovidi .div-der .costo').addClass('oculto');


			var _delay_2 =setInterval(function(){
				clearInterval(_delay_2);
				$('#avisos_inmovidi .div-izq').addClass('oculto');

				var _delay_3 =setInterval(function(){
					clearInterval(_delay_3);
					$('#avisos_inmovidi').addClass('oculto');

					var _delay_ini=setInterval(function(){

						clearInterval(_delay_ini);

						GL_INDICE_ROTADOR_INMOVIDI++;

						if(GL_INDICE_ROTADOR_INMOVIDI==GL_AVISOS_INMOVIDI.length){
							GL_INDICE_ROTADOR_INMOVIDI=0;
						}


						$('#avisos_inmovidi').css('background-image','url("IMG/AVISOS/VISTA_PREVIA/WEB/'+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].img_previa+'.'+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].img_previa_ext+'")');

						$('#avisos_inmovidi .aviso_inmovidi .div-izq img').attr('src','IMG/AVISOS/VISTA_PREVIA/WEB/'+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].img_previa+'.'+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].img_previa_ext);

						$('#avisos_inmovidi .aviso_inmovidi .div-der .costo').html((GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].costo==0? 'S/. Consultar': (GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].moneda=='soles'? 'S/.':'$')+' '+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].costo) );
						$('#avisos_inmovidi .aviso_inmovidi .div-der .titulo').html(GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].titulo);




						$('#avisos_inmovidi').removeClass('oculto');




						var _delay1 =setInterval(function(){
							clearInterval(_delay1);
							$('#avisos_inmovidi .div-izq').removeClass('oculto');


							var _delay2 =setInterval(function(){
								clearInterval(_delay2);
								$('#avisos_inmovidi .div-der .costo').removeClass('oculto');


								var _delay3 =setInterval(function(){
									clearInterval(_delay3);
									$('#avisos_inmovidi .div-der .titulo').removeClass('oculto');
								},300);



							},500);


						},500);



					},1500);



				},500);
				
			},500);
		},300);







		setInterval(function(){


			$('#avisos_inmovidi .div-der .titulo').addClass('oculto');

			var delay_1 =setInterval(function(){
				clearInterval(delay_1);
				$('#avisos_inmovidi .div-der .costo').addClass('oculto');


				var delay_2 =setInterval(function(){
					clearInterval(delay_2);
					$('#avisos_inmovidi .div-izq').addClass('oculto');

					var delay_3 =setInterval(function(){
						clearInterval(delay_3);
						$('#avisos_inmovidi').addClass('oculto');

						var delay_ini=setInterval(function(){

							clearInterval(delay_ini);

							GL_INDICE_ROTADOR_INMOVIDI++;
							if(GL_INDICE_ROTADOR_INMOVIDI==GL_AVISOS_INMOVIDI.length){
								GL_INDICE_ROTADOR_INMOVIDI=0;
							}

							$('#avisos_inmovidi').css('background-image','url("IMG/AVISOS/VISTA_PREVIA/WEB/'+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].img_previa+'.'+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].img_previa_ext+'")');


							$('#avisos_inmovidi .aviso_inmovidi .div-izq img').attr('src','IMG/AVISOS/VISTA_PREVIA/WEB/'+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].img_previa+'.'+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].img_previa_ext);

							$('#avisos_inmovidi .aviso_inmovidi .div-der .costo').html((GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].costo==0? 'S/. Consultar': (GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].moneda=='soles'? 'S/.':'$')+' '+GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].costo) );
							$('#avisos_inmovidi .aviso_inmovidi .div-der .titulo').html(GL_AVISOS_INMOVIDI[GL_INDICE_ROTADOR_INMOVIDI].titulo);


							$('#avisos_inmovidi').removeClass('oculto');

							var delay1 =setInterval(function(){
								clearInterval(delay1);
								$('#avisos_inmovidi .div-izq').removeClass('oculto');


								var delay2 =setInterval(function(){
									clearInterval(delay2);
									$('#avisos_inmovidi .div-der .costo').removeClass('oculto');


									var delay3 =setInterval(function(){
										clearInterval(delay3);
										$('#avisos_inmovidi .div-der .titulo').removeClass('oculto');
									},300);



								},500);


							},500);



						},1500);



					},500);
					
				},500);
			},300);


		},8000);






	},500);




}




var GL_AVISOS_RELACIONADOS=new Array();
function fun_get_noticias_relacionadas(id_noticia){


	$.ajax({
        url: "MOD/INSTALACIONES/POST/get_noticias_relacionadas.php",
        type: "POST",
        datatype:'json',
        data:{id_noticia:id_noticia},
        async:true,
        beforeSend: function(objeto){
        	
        },	        
		success: function(data){


			if(data=="mysql_no"){
				FMSG_ERROR_CONEXION();
			}else{

				if(data!='no data'){

					respuesta=$.parseJSON(data);
					delay=0.2;


						$('#visor_portafolios .columna .comp-galeria').html('');
						$('#visor_portafolios .columna .comp-galeria').addClass('comp-animacion-ini');

						$('#visor_portafolios .columna .comp-galeria').attr('id','');

					GL_AVISOS_RELACIONADOS=new Array();
					for(var index in respuesta){

						GL_AVISOS_RELACIONADOS[respuesta[index].id]=respuesta[index];



						delay_aux=delay;
						numero='';
						if(delay_aux>=1){
							numero='_'+Math.floor(delay_aux);
							delay_aux=delay_aux%1;

						}
						if(delay_aux>0){
							delay_aux=Math.ceil(delay_aux*10);
							numero=numero+'_0'+delay_aux;
						}
						trans_delay='trans_delay'+numero;


						delay_aux=delay+0.4;

						numero='';
						if(delay_aux>=1){
							numero='_'+Math.floor(delay_aux);
							delay_aux=delay_aux%1;

						}
						if(delay_aux>0){
							delay_aux=Math.ceil(delay_aux*10);
							numero=numero+'_0'+delay_aux;
						}
						trans_delay_2='trans_delay'+numero;



						html_elemento='<elemento data-src="IMG/NOTICIAS/FONDOS/WEB/'+respuesta[index].id_img+'.'+respuesta[index].ext_img+'" data-msrc="IMG/NOTICIAS/FONDOS/WEB/'+respuesta[index].id_img+'.'+respuesta[index].ext_img+'" data-espacio="1" data-titulo="" data-subtitulo="'+respuesta[index].titulo+'">'+

								 '<ClassExtra DOMdestino="cg-elemento" class="trans_bezier_05 '+trans_delay+' anim-escala_0"></ClassExtra>'+
								 '<AttrExtra DOMdestino="cg-elemento" atributos="data-id_noticia='+"'"+respuesta[index].id_noticia+"'"+ '"></AttrExtra>'+

					            '<ClassExtra DOMdestino="cg-elemento-titulo" class="responsive-fontsize trans_bezier_05 '+trans_delay_2+' anim-oculto-opacity anim-desplaza-arriba-50"></ClassExtra>'+
					            '<ClassExtra DOMdestino="cg-elemento-subtitulo" class="responsive-fontsize trans_bezier_05 '+trans_delay_2+' anim-oculto-opacity anim-desplaza-abajo-50"></ClassExtra>'+
														'</elemento>';

						delay+=0.2;

						$('#visor_portafolios .columna .comp-galeria').append(html_elemento);

					}


						var delay_ini=setInterval(function(){

							if(GL_COMPONENTE_GALERIA){
								clearInterval(delay_ini);
								GL_COMPONENTE_GALERIA.ini_galeria_por_id($('#visor_portafolios .columna .comp-galeria'));
								GL_COMPONENTE_CARGANDO.cargar_msrc();
								GL_COMPONENTE_CARGANDO.asignar_fondos_css_img();

								$('#visor_portafolios .columna .comp-galeria').removeClass('comp-animacion-ini');
							}
						},1000);

					
				}

					

			}
		}

	});
}





function fun_aumentar_visita(id){
	$.ajax({
        url: "POST/aumentar_visita_anuncio.php",
        type: "POST",
        datatype:'json',
        data:{id_aviso:id},
        async:true,
        beforeSend: function(objeto){
        	
        },	        
		success: function(data){
			
			if(data=="mysql_no"){
				FMSG_ERROR_CONEXION();
			}else{

			}
		}

	});
}




function fun_imprimir_resultados(checks_busqueda){

	var cont=0;

	$('.content_resultados_avisos').slideDown(500);

	if(GL_AVISOS.length>0){
		
		html_avisos='';
		for(var index in GL_AVISOS){
			cont++;
			html_avisos+=fun_armar_html_result_aviso(cont,GL_AVISOS[index],checks_busqueda);
		}


		$('#barra_de_busqueda .resultados_avisos').html(html_avisos);
		

	  	setMarkers(GL_MAPA, GL_AVISOS);



		num_avisos=$('.content_resultados_avisos .resultado-aviso.oculto').length;
		cont=0;
		var delay_muestra_avisos=setInterval(function(){

				if(cont==num_avisos){
					clearInterval(delay_muestra_avisos);
				}else{
					$('.content_resultados_avisos .resultado-aviso.oculto').first().removeClass('oculto');
				}
		
			cont++;
		},300);
	}else{

		$('#barra_de_busqueda .resultados_avisos').html('<span class="resultado_vacio">No se encontraron avisos, <span id="cambiar_modo_busqueda">cambie el modo de b&uacute;squeda</span> o desplace c&iacute;rculo morado en el mapa e intente de nuevo</span>');
	  	setMarkers(GL_MAPA, GL_AVISOS);
	}

}



function fun_armar_html_result_aviso(cont,aviso,checks_busqueda){



    trans_top=(cont-1)*170;
    estilo='-webkit-transform: translate3d(0px,'+trans_top+'px,0px);'+
		'-moz-transform: translate3d(0px,'+trans_top+'px,0px);'+
		'-ms-transform: translate3d(0px,'+trans_top+'px,0px);'+
		'-o-transform: translate3d(0px,'+trans_top+'px,0px);'+
		'transform: translate3d(0px,'+trans_top+'px,0px);';


    html='<div class="resultado-aviso-content" style="'+estilo+'">'+
    		'<div id="resultado-aviso-'+aviso.id+'" data-id="'+aviso.id+'" class="resultado-aviso resultado-mostrado-aviso oculto">'+
	          '<div class="div-izq">'+
	            '<div class="img-previa"><img src="IMG/AVISOS/VISTA_PREVIA/MINI/'+aviso.img_previa+'.'+aviso.img_previa_ext+'"></div>'+
	          '</div>'+
	          '<div class="div-der">'+
	            '<div class="costo">'+(aviso.costo==0? 'S/. Consultar': (aviso.moneda=='soles'? 'S/.':'$')+' '+aviso.costo) +'</div>'+
	            '<div class="titulo">'+aviso.titulo+'</div>'+
	            '<div class="info_extra">'+
	              '<div class="area">'+aviso.area+' m2</div>'+
	              '<div class="habitaciones"><div class="text">'+aviso.habitaciones+'</div><div class="img"></div></div>'+
	              '<div class="banios"><div class="text">'+aviso.banios+'</div> <div class="img"></div></div>'+
	            '</div>'+
	          '</div>'+

		          '<div class="info-detalles-aviso ">'+
		          	'<div class="div-img-previa oculto">'+
		          		'<div class="img-previa-detalle"><img src="IMG/AVISOS/VISTA_PREVIA/WEB/'+aviso.img_previa+'.'+aviso.img_previa_ext+'"></div>'+
		          		'<div class="info-titulo">'+
			          		'<div class="div-costo">'+(aviso.costo==0? 'S/. Consultar': (aviso.moneda=='soles'? 'S/.':'$')+' '+aviso.costo) +'</div>'+
				            '<div class="div-titulo">'+aviso.titulo+'</div>'+
			            '</div>'+
		          	'</div>'+
		          	'<div class="div-info-aviso">'+
		          		'<div class="content-info-aviso">'+

		          			'<div class="div_vistas">'+aviso.contador_vistas+' visitas</div>'+

			          		'<div class="div_fecha">Publicado el '+
			          		fun_oracion_fecha_DM(fun_fecha_invierte_formato(aviso.fecha_dia))+
			          		'</div>'+


			          		'<div class="btns_fb"></div>'+

			          		'<div class="titulo_descripcion">Descripci&oacute;n del inmueble:<br></div>'+
			          		'<div class="descripcion">'+
			          			aviso.descripcion+
			          		'</div>'+
			          		'<div class="titulo_caracteristicas">Caracter&iacute;sticas:<br></div>';


			          	if(!checks_busqueda){
			          		checks_busqueda=new Array();
			          	}

						var datos_extra='';
						if(aviso.cochera==1){
							clase_resalta='';
							if(checks_busqueda['cochera']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Cochera</div> </li>';
						}
						if(aviso.jardin==1){
							clase_resalta='';
							if(checks_busqueda['jardin']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Jard&iacute;n</div> </li>';
						}
						if(aviso.terraza==1){
							clase_resalta='';
							if(checks_busqueda['terraza']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Terraza</div> </li>';
						}
						if(aviso.area_deportiva==1){
							clase_resalta='';
							if(checks_busqueda['area_deportiva']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">&Aacute;rea deportiva</div> </li>';
						}
						if(aviso.bbq==1){
							clase_resalta='';
							if(checks_busqueda['bbq']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">&Aacute;rea BBQ</div> </li>';
						}
						if(aviso.patio==1){
							clase_resalta='';
							if(checks_busqueda['patio']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Patio</div> </li>';
						}
						if(aviso.jacuzzi==1){
							clase_resalta='';
							if(checks_busqueda['jacuzzi']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Jacuzzi</div> </li>';
						}
						if(aviso.guardian==1){
							clase_resalta='';
							if(checks_busqueda['guardian']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Guardi&aacute;n</div> </li>';
						}
						if(aviso.piscina==1){
							clase_resalta='';
							if(checks_busqueda['piscina']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Piscina</div> </li>';
						}
						if(aviso.internet==1){
							clase_resalta='';
							if(checks_busqueda['internet']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Internet</div> </li>';
						}
						if(aviso.cuarto_de_servicio==1){
							clase_resalta='';
							if(checks_busqueda['cuarto_de_servicio']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Cuarto de servicio</div> </li>';
						}
						if(aviso.amoblado==1){
							clase_resalta='';
							if(checks_busqueda['amoblado']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Amoblado</div> </li>';
						}
						if(aviso.closet==1){
							clase_resalta='';
							if(checks_busqueda['closet']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Closet</div> </li>';
						}
						if(aviso.ascensor==1){
							clase_resalta='';
							if(checks_busqueda['ascensor']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Ascensor</div> </li>';
						}
						if(aviso.deposito==1){
							clase_resalta='';
							if(checks_busqueda['deposito']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Dep&oacute;sito</div> </li>';
						}
						if(aviso.club_house==1){
							clase_resalta='';
							if(checks_busqueda['club_house']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Club House</div> </li>';
						}
						if(aviso.portero_electrico==1){
							clase_resalta='';
							if(checks_busqueda['portero_electrico']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Portero El&eacute;ctrico</div> </li>';
						}
						if(aviso.balcon==1){
							clase_resalta='';
							if(checks_busqueda['balcon']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Balc&oacute;n</div> </li>';
						}
						if(aviso.frente_a_parque==1){
							clase_resalta='';
							if(checks_busqueda['frente_a_parque']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Frente al parque</div> </li>';
						}
						if(aviso.kitchenette==1){
							clase_resalta='';
							if(checks_busqueda['kitchenette']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Kitchenette</div> </li>';
						}
						if(aviso.lavanderia==1){
							clase_resalta='';
							if(checks_busqueda['lavanderia']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Lavanderia</div> </li>';
						}
						if(aviso.cocina_repostero==1){
							clase_resalta='';
							if(checks_busqueda['cocina_repostero']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Cocina con repostero</div> </li>';
						}
						if(aviso.vista_calle==1){
							clase_resalta='';
							if(checks_busqueda['vista_calle']){
								clase_resalta="resaltado";
							}
							datos_extra+='<li class="'+clase_resalta+'"><div class="img"></div><div class="text">Vista a la calle</div> </li>';
						}

				            html+='<ul class="info_extra">'+
				              '<li class="area">Area construida: '+aviso.area+' m2</li>'+
				              '<li class="habitaciones"><div class="img"></div><div class="text">Con '+aviso.habitaciones+' habitaciones</div></li>'+
				              '<li class="banios"><div class="img"></div><div class="text">Con '+aviso.banios+' ba&ntilde;os</div> </li>'+
				              datos_extra+
				            '</ul>'+

			          		'<div class="titulo_direccion">Direcci&oacute;n</div>'+
				            '<div class="div_direccion">'+
				            	aviso.direccion+
				            '</div>';


							if(aviso.video!=''){

								video=aviso.video;

								if(video.indexOf('v=')!=-1){
									video=(video).split('v=')[1];
								}

								if(video.indexOf('&')!=-1){
									video=video.split('&')[0];
								}

								if(video && video!=''){

									height_iframe=9*parseInt($('#barra_de_busqueda').css('width').replace('px',''))/16;
									

									html+='<div class="titulo_video">V&iacute;deo de referencia</div><div class="aviso_video"> <iframe style="height:'+height_iframe+'px" src="https://www.youtube.com/embed/'+video+'?autoplay=0" frameborder="0" allowfullscreen></iframe></div>';

								}


				            }



				            if(aviso.fotos.length>0){

				            	html+='<div class="titulo_fotos">Fotos del inmueble</div>'+

				            '<div class="div_fotos">'+

				            '</div>';
				            }


				            html+='<div class="div_anunciante">'+
				            	'<div class="titulo">Contactar con el anunciante'+
				            	'</div>'+
				            	'<div class="div_avatar">'+
				            		'<div class="content-avatar"><img src="IMG/USUARIOS/MOVIL/'+aviso.usuario_img+'.'+aviso.usuario_img_ext+'"></div>'+
				            	'</div>'+ 
				            	'<div class="div_nombre">'+
				            		aviso.nombre+
				            	'</div>'+
				            	'<div class="div_descripcion">'+
				            		aviso.presentacion+
				            	'</div>'+

				            	'<div class="dif_form_contacto_contenedor">'+
					            	'<div class="div_form_contacto trans_bezier_05">'+
						            	'<div class="campo"><textarea id="contact_aviso_mensaje" placeholder="Escribe tu mensaje"></textarea><div class="msj_aux oculto">Campo obligatorio</div></div>'+
						            	'<div class="campo"><input type="text" id="contact_aviso_nombre" placeholder="Nombre"/> <div  class="msj_aux oculto">Campo obligatorio</div> </div>'+
						            	'<div class="campo"><input type="text" id="contact_aviso_correo" placeholder="Correo"/><div  class="msj_aux oculto">Campo obligatorio</div></div>'+
						            	'<div class="campo"><input type="text" id="contact_aviso_telefono" placeholder="Teléfono de contacto"/></div>'+
						            	'<div class="campo"><div id="btn_enviar" data-id="'+aviso.id+'" ><div class="content">Contactar</div></div></div>'+   
 
					            	'</div>'+
						            	'<div class="div_mensaje_icono trans_bezier_05 oculto"><div class="contenedor-tabla"><div class="contenedor-celda"> <div id="icono_mensaje" class="trans_bezier_1" ><div class="content trans_bezier_1 trans_delay_05"></div></div></div></div></div>'+ 
				            	'</div>'+

				            '</div>'+
		          		'</div>'+
		          	'</div>'+
		          '</div>'+



          '</div>'+


        '</div>';

        return html;

}







function fun_resize_obj_galeria(id_dom){
	fun_resize();

	fun_resize_fontsize('#portafolios');

	fun_resize_fontsize('#content_visor_detalles_portafolios');



	if($(window).width()<600){

		$('#portafolios').addClass('responsive');
		
	}else{
	
		$('#portafolios').removeClass('responsive');

	}

	$('#portafolios').removeClass('responsive_s');		
	$('#portafolios').removeClass('responsive_m');

	if($(window).width()<350){

		$('#portafolios').addClass('responsive_s');
	}else{
		if($(window).width()<600){

			$('#portafolios').addClass('responsive_m');
		}
	}


		$('#portafolios').removeClass('altura_responsive');
	if(parseInt($('#portafolios ').css('height').replace('px',''))< $('#portafolios .comp-galeria-contenido >.contenedor-tabla').css('height').replace('px','')){		
		$('#portafolios').addClass('altura_responsive');
		
	}else{
	

	}

}





function fun_inicia_cargando(){
	var delay=setInterval(function(){
		clearInterval(delay);
		$('body').removeClass('sin_scroll');

		$('.comp-cargando #imagen').addClass('mostrado');
		$('.comp-cargando #comp-cargando-barra').addClass('mostrado');

	},100);

}




function fun_resize_fontsize(id_dom){

		$(id_dom+' .responsive-fontsize').each(function(){

			var proporcion=$(this).data('propfontsize');


			if($(this).data('referfontsize')){

				if($(this).data('referfontsize')=='window'){
					ancho_referencia=$(window).width();
				}else{
					try{

						ancho_referencia=parseInt($($(this).data('referfontsize')).css('width').replace('px',''));
					}catch(e){

					}
				}
			}else{
				ancho_referencia=parseInt($(this).css('width').replace('px',''));
				
			}

			
			font_size=ancho_referencia*parseFloat(proporcion)/100;
			
			if(font_size<parseInt($(this).data('minfontsize'))){
				font_size=parseInt($(this).data('minfontsize'));
			}

			$(this).css('font-size',font_size+'px');
			
		});



}





function fun_resize_obj_contactenos(id_dom){

fun_resize();

var delay=setInterval(function(){
	clearInterval(delay);	

	/*if(parseInt($('#contactenos').css('height').replace('px',''))< $('#contactenos .comp-contactenos').css('height').replace('px','')){		
		$('#contactenos').addClass('altura_responsive');
	}else{
		$('#contactenos').removeClass('altura_responsive');
	}*/

	$(id_dom+' .responsive-fontsize').each(function(){

		var proporcion=$(this).data('propfontsize');
		
		font_size=parseInt($(this).css('width').replace('px',''))*parseFloat(proporcion)/100;
		
		if(font_size<parseInt($(this).data('minfontsize'))){
			font_size=parseInt($(this).data('minfontsize'));
		}

		$(this).css('font-size',font_size+'px');
	});

},100);



	$('#contactenos').removeClass('altura_responsive');

	if(parseInt($('#contactenos').css('height').replace('px',''))-50< parseInt($('#contactenos #comp-contactenos-0>.comp-contactenos-content>.comp-contactenos-celda').css('height').replace('px','')) ){	

		$('#contactenos').addClass('altura_responsive');

	}

}



function fun_resize_obj_informacion(id_dom){

	$('#informacion').removeClass('altura_responsive');


	if(parseInt($('#informacion').css('height').replace('px',''))-$(window).height()*25/100< parseInt($('#informacion .comp-informacion>.contenedor-tabla>.contenedor-celda>.comp-info-contenedor-bloques').css('height').replace('px','')) ){

		$('#informacion').addClass('altura_responsive');

	}

}




function fun_comp_cargando_retirado(){
	

	var delay_inicial=setInterval(function(){
		clearInterval(delay_inicial);
		$('#seccion_funcion-buscar').removeClass('oculto');

	},2600);

	fun_get_avisos_inmovidi();


	switch($('#gl_get_view').val()){

		case 'anuncios':

			var id_aviso=$('#gl_get_id').val().split('_')[0];

			if($('#gl_get_consulta_data').val()!=''){

				var respuesta=$.parseJSON($('#gl_get_consulta_data').val());
				GL_AVISOS=new Array();
				var GL_CONT_AVISOS=0;
				for(var index in respuesta){
					GL_AVISOS[respuesta[index].id]=respuesta[index];

				}
			}else{

			}


			var delay1=setInterval(function(){
				clearInterval(delay1);


				fun_animacion_espacio_busqueda(GL_AVISOS[id_aviso].coor_latitud,GL_AVISOS[id_aviso].coor_longitud);
				var delay2=setInterval(function(){
					clearInterval(delay2);
					
					if($('#gl_get_consulta_data').val()!=''){


						fun_imprimir_resultados();

					}else{

					}





					var delaymove=setInterval(function(){
						if(GL_MAPA){

							clearInterval(delaymove);


					 		$('#distrito option[value="pos_actual"]').remove();
					 		$('#distrito').prepend('<option value="pos_actual">Posici&oacute;n actual</option>');
					 		$('#distrito').val('pos_actual');
					 		


							if(!GL_CIRCULO_BUSQUEDA){
								var circulo = {
								      strokeColor: 'rgb(20, 22, 204)',
								      strokeOpacity: 0.7,
								      strokeWeight: 2,
								      fillColor: 'rgb(20, 70, 204)',
								      fillOpacity: 0.4,
								      map: GL_MAPA,
								      draggable:false,
								      editable:true,
								      center: new google.maps.LatLng(GL_AVISOS[id_aviso].coor_latitud, GL_AVISOS[id_aviso].coor_longitud),
								      radius: 2000
								    };
								    // Add the circle for this city to the map.

								    if(GL_CIRCULO_BUSQUEDA){
								   		GL_CIRCULO_BUSQUEDA.setMap(null);
								    }

								    GL_CIRCULO_BUSQUEDA = new google.maps.Circle(circulo);


							 		google.maps.event.addListener(GL_CIRCULO_BUSQUEDA, 'center_changed', function(){



							 		if($('#barra_de_busqueda .content_resultados_avisos').hasClass('oculto')){
							 			//con esto verificamos si el contenedor de resultados est'a oculto

										$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');						
										$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('sin_selec_3');
										$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('select');

										$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').addClass('sin_selec_1');
										$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').removeClass('select');
										var delay=setInterval(function(){
											clearInterval(delay);
											$('#barra_de_busqueda .content_resultados_avisos').removeClass('oculto');
										},500);

							 		}

								 	fun_get_avisos(true,false);
							 		
							    });

							 	google.maps.event.addListener(GL_CIRCULO_BUSQUEDA, 'radius_changed', function(){

							 		if(GL_CIRCULO_BUSQUEDA.getRadius()>3000){
							 			GL_CIRCULO_BUSQUEDA.setRadius(3000);
							 		}else{

								 		if(GL_CIRCULO_BUSQUEDA.getRadius()<200){

							 				GL_CIRCULO_BUSQUEDA.setRadius(200);

								 		}
							 		}



							 		if($('#barra_de_busqueda .content_resultados_avisos').hasClass('oculto')){
							 			//con esto verificamos si el contenedor de resultados est'a oculto

										$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');						
										$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('sin_selec_3');
										$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('select');

										$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').addClass('sin_selec_1');
										$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').removeClass('select');
										var delay=setInterval(function(){
											clearInterval(delay);
											$('#barra_de_busqueda .content_resultados_avisos').removeClass('oculto');
										},500);

							 		}

							 		fun_get_avisos(true,false);
							 		

								 	//fun_get_avisos(GL_CIRCULO_BUSQUEDA.getCenter().lat(),GL_CIRCULO_BUSQUEDA.getCenter().lng(),false);
							 		
							    });

							}







							fun_moveToLocation(GL_AVISOS[id_aviso].coor_latitud,GL_AVISOS[id_aviso].coor_longitud,-250,0);
							$('.content_resultados_avisos .resultado-aviso[data-id="'+id_aviso+'"]').click();

						}
					},500);


				},6000);

			},5000);

		break;

		case 'noticias':




			var delay1=setInterval(function(){
				clearInterval(delay1);

				$('html,body').animate({scrollTop: $('#portafolios').offset().top},1000);


					var id_noticia=$('#gl_get_id').val().split('_')[0];
					
					if($('#gl_get_consulta_data').val()!=''){

						var noticia=$.parseJSON($('#gl_get_consulta_data').val());


						for(var index in noticia){


							if(!GL_NOTICIAS[noticia[index].id_noticia]){

								GL_NOTICIAS[noticia[index].id_noticia]=noticia[index];


									/*Desarrollado por Dante Vidal Tueros*/
									var html_fotos='<div class="comp-visor-foto" data-idfoto="0">'+
							          '<img  data-src="IMG/NOTICIAS/FONDOS/WEB/'+noticia[index].id_img+'.'+noticia[index].ext_img+'" data-msrc="IMG/NOTICIAS/FONDOS/MOVIL/'+noticia[index].id_img+'.'+noticia[index].ext_img+'" class="comp-cargando-img-redirect" data-redirect="true" data-destino="#comp-visor-fotos-0 .comp-visor-foto[data-idfoto='+"'0'"+']">'+
							          	'<div class="comp-visor-foto-descripcion">'+
											'<div class="comp-visor-titulo-foto">'+
												noticia[index].titulo+
											'</div>'+
											'<div class="comp-visor-desc-foto">'+
												( noticia[index].descripcion.length>150 ? noticia[index].descripcion.substring(0,140)+'...' : noticia[index].descripcion  ) +
											'<span class="noticia-leer_mas"">Leer m&aacute;s</span><span class="noticia-leer_mas_oculto" data-id_noticia="'+noticia[index].id_noticia+'"></span></div>'+
										'</div>'+
							        '</div>';		

									var html_mini_fotos='<div class="comp-visor-fotoprev"  data-idvisor="#comp-visor-fotos-0" data-idfoto="0">'+
										'<div class="contenedor-tabla"><div class="contenedor-celda">'+
											'<div class="comp-visor-fotoprev-content">'+
												'<div class="previmg"></div>'+

											'</div>'+
										'</div>'+
										'</div>'+
							        '</div>';	


							}
						}


						$('#comp-visor-fotos-0 .comp-visor-fotos-contenido').prepend(html_fotos);
						$('#comp-visor-fotos-0 .comp-vf-barra-contenido').prepend(html_mini_fotos);


						var delaymove=setInterval(function(){
							clearInterval(delaymove);
							fun_mostrar_info_noticia(id_noticia);
						},2000);
/*

*/

					}


			},500);

		break;
	
	}
}






function fun_animacion_espacio_busqueda(latitud,longitud){





	$('#contenedor_avisos_inmovidi').addClass('oculto');


      $('html,body').animate({scrollTop: 0},1000);


		$('#inicio #barra_de_busqueda').addClass('full_altura');
		$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');

		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').addClass('oculto');
		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="noticias"]').addClass('oculto');
		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="contacto"]').addClass('oculto');




		var delay=setInterval(function(){
			clearInterval(delay);

						if($(window).width()>800){

							//$('body').addClass('comp-carga');
						}
			//$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('centrado');			
			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"] .texto').html('Buscando...');


			//calculamos el ancho para el mapa en toda la pantalla
			$('.contenedor_mapa').css('width',$(window).width()+'px');
			$('.contenedor_mapa').css('height',$(window).height()+'px');

			$('#content_lineas_dinamicas').addClass('oculto');

			//if(!GL_MAPA){

				fun_carga_google_maps(latitud,longitud);		

			//}else{

			//}

		},1500);

		var delay_1=setInterval(function(){
			clearInterval(delay_1);



		},2000);

		var delay2=setInterval(function(){
			clearInterval(delay2);



			$('#inicio #barra_de_busqueda').removeClass('full_altura');
			$('#inicio #barra_de_busqueda').removeClass('inferior');
			$('#inicio #barra_de_busqueda').addClass('lateral');
			var delay2_1=setInterval(function(){  //se hace un delay pues al colocar la clase lateral a seccion content funciones, se cambia el position absoluto a initial, lo cual arruinaria la animacion, asi que mejor se hace dicho cambio cuando ya se oculto dicha seccion
				clearInterval(delay2_1);

				$('#inicio #barra_de_busqueda .seccion_content_funciones').addClass('lateral');
			},1500);

			$('#inicio #barra_de_busqueda .seccion_content_funciones').addClass('no_events');
			
			
			$('#inicio #barra_de_busqueda').data('posicion','lateral');
	

			
			$('#slider-portal').addClass('oculto');


		},3000);

		var delay3=setInterval(function(){
			clearInterval(delay3);
			
			$('.barra_content .seccion_inputs').addClass('lateral');


			var delay_muestra_mapa=setInterval(function(){
				if(GL_MAPA){
					clearInterval(delay_muestra_mapa);

	  				$('.content_mapa_buscador').removeClass('oculto');
				}
			},500);
		},3500);

		var delay4=setInterval(function(){
			clearInterval(delay4);

			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').removeClass('oculto');
			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="noticias"]').removeClass('oculto');


			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('centrado');

			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('sin_selec_3');
			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('select');

			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"] .texto').html('Buscar');	

			$('.barra_content .seccion_inputs .seccion_icono').addClass('lateral');


			$('#barra_de_busqueda .barra_content').addClass('lateral');
			$('.content_resultados_avisos').show();

		},5000);


}


var GL_RESPONSIVE_BARRA_VERTICAL=false;

function fun_ajusta_barra_vertical_responsive(){



GL_RESPONSIVE_BARRA_VERTICAL=true;

		$('#inicio #barra_de_busqueda').addClass('full_altura');
		$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');

		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').addClass('oculto');
		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="noticias"]').addClass('oculto');


		var delay_1=setInterval(function(){
			clearInterval(delay_1);

			//$('.barra_content .seccion_inputs').addClass('ancho_full');


		},2000);

		var delay2=setInterval(function(){
			clearInterval(delay2);



			$('#inicio #barra_de_busqueda').removeClass('full_altura');
			$('#inicio #barra_de_busqueda').removeClass('inferior');
			$('#inicio #barra_de_busqueda').addClass('lateral');
			var delay2_1=setInterval(function(){  //se hace un delay pues al colocar la clase lateral a seccion content funciones, se cambia el position absoluto a initial, lo cual arruinaria la animacion, asi que mejor se hace dicho cambio cuando ya se oculto dicha seccion
				clearInterval(delay2_1);

				$('#inicio #barra_de_busqueda .seccion_content_funciones').addClass('lateral');
			},500);

			//$('#inicio #barra_de_busqueda .seccion_content_funciones').addClass('no_events');
			
			
			$('#inicio #barra_de_busqueda').data('posicion','lateral');
	

		},3000);

		var delay3=setInterval(function(){
			clearInterval(delay3);
			
			$('.barra_content .seccion_inputs').addClass('lateral');

		},3500);

		var delay4=setInterval(function(){
			clearInterval(delay4);

			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').removeClass('oculto');
			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="noticias"]').removeClass('oculto');


			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('centrado');


			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('select');

			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"] .texto').html('Buscar');	

			$('.barra_content .seccion_inputs .seccion_icono').addClass('lateral');


			$('#barra_de_busqueda .barra_content').addClass('lateral');



		},4500);


		var delay5=setInterval(function(){
			clearInterval(delay5);

			$('#barra_de_busqueda #seccion_funcion-buscar').removeClass('oculto');

		},5500);


}





function fun_animacion_ocultar_espacio_busqueda(noticias){

GL_RESPONSIVE_BARRA_VERTICAL=false;

/*
	$('#barra_de_busqueda #distrito option[value="pos_actual"]').remove();

	$('#barra_de_busqueda #distrito').val($('#barra_de_busqueda #distrito option').first().attr('value'));

*/


		$('#seccion_bus_mas_opciones').slideUp(300);



		$('.content_mapa_buscador ').addClass('oculto');
		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').addClass('oculto');
		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="noticias"]').addClass('oculto');
		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="contacto"]').addClass('oculto');
		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="atras"]').addClass('oculto');



		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('centrado');

		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('sin_selec_3');
		$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').addClass('select');



		$('.content_resultados_avisos').fadeOut(300);
		$('.barra_content .seccion_inputs').removeClass('lateral');
		//$('.barra_content .seccion_inputs').removeClass('ancho_full');



		var delay3=setInterval(function(){
			clearInterval(delay3);
			
			$('#barra_de_busqueda .barra_content').removeClass('lateral');
			$('.barra_content .seccion_inputs .seccion_icono').removeClass('lateral');

			$('#inicio #barra_de_busqueda').removeClass('lateral');
			$('#inicio #barra_de_busqueda').addClass('full_altura');
			$('.content_mapa_buscador #mapa_buscador').html('');
			$('#barra_de_busqueda .resultados_avisos').html('');
			GL_AVISOS=new Array();
			GL_CONT_AVISOS=0;

			$('#contenedor_avisos_inmovidi').removeClass('oculto');
		},1500);


		var delay2=setInterval(function(){
			clearInterval(delay2);



			$('#inicio #barra_de_busqueda').addClass('inferior');
			var delay2_1=setInterval(function(){  //se hace un delay pues al colocar la clase lateral a seccion content funciones, se cambia el position absoluto a initial, lo cual arruinaria la animacion, asi que mejor se hace dicho cambio cuando ya se oculto dicha seccion
				clearInterval(delay2_1);
				$('#inicio #barra_de_busqueda .seccion_content_funciones').removeClass('lateral');
			},1000);

			$('#inicio #barra_de_busqueda .seccion_content_funciones').removeClass('no_events');
			
			
			$('#inicio #barra_de_busqueda').data('posicion','inferior');
	

			$('#slider-portal').removeClass('oculto');



		},2000);


	var delay=setInterval(function(){

			$('body').removeClass('comp-carga');
			clearInterval(delay);


			$('#inicio #barra_de_busqueda').removeClass('full_altura');


			$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion').addClass('oculto');

			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="vender"]').removeClass('oculto');
			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="noticias"]').removeClass('oculto');
			
				width_logo=120;
					/*$('#barra_de_busqueda').removeClass('responsive_w830');
					$('#barra_de_busqueda').removeClass('responsive_w955');
					$('#barra_de_busqueda').removeClass('responsive_w1120');
					$('#barra_de_busqueda').removeClass('responsive_w1210');
			*/
				if($(window).width()<=830){
					//$('#barra_de_busqueda').addClass('responsive_w830');
					width_logo=70;
				}else{

					if($(window).width()<=1120){

					//	$('#barra_de_busqueda').addClass('responsive_w1120');
						width_logo=100;
					}


				}


			//$('.barra_content .seccion_inputs').css('width',($(window).width()-width_logo - 10)+'px');
			//$('.barra_content .seccion_inputs').css('left','120px');

		},2500);


		var delay_f=setInterval(function(){
			clearInterval(delay_f);

			$('.barra_content .seccion_inputs .seccion_icono[data-opcion="buscar"]').removeClass('centrado');	

		},4500);

		var delay_f2=setInterval(function(){
			clearInterval(delay_f2);


			$('#barra_de_busqueda .seccion_content_funciones .seccion_funcion .div_borde_buscador').css('width','initial');



			$('#barra_de_busqueda .seccion_content_funciones #seccion_funcion-buscar').removeClass('oculto');
		},6000);

		if(noticias){

			var delay_noticias=setInterval(function(){
				clearInterval(delay_noticias);

				var top_portafolios=$('#portafolios').offset().top;

				$('html,body').animate({scrollTop:top_portafolios},1000);
			},7000);

		}

}


function fun_inicia_obj_contactenos(id_dom){

		mod_contacto=new OBJ_MOD_CONTACTO(false);
		mod_contacto.get();

}

function fun_inicia_obj_informacion(id_dom){

		mision_vision=new OBJ_PRESENTACION('#div_qns_sms','#div_mision_vision');
		mision_vision.get_mision_vision();
		

}


function fun_llenar_info_contacto(){

	//$('#direccion_info').html(GL_CONTACTO[1].direccion);
	$('#telefono_info').html(GL_CONTACTO[1].telefono);
	$('#email_info').html(GL_CONTACTO[1].email);
}





var GL_INFO_WINDOW;
var GL_MARCADORES_LUGARES_CERCA=[];

function fun_mostrar_lugares_cerca(tipos){

fun_limpiar_lugares_cerca();
  var request = {
    location: GL_CIRCULO_BUSQUEDA.getCenter(),
    radius: GL_CIRCULO_BUSQUEDA.getRadius()+1000,
    types:tipos 
  };






  GL_INFO_WINDOW = new google.maps.InfoWindow();
  var service = new google.maps.places.PlacesService(GL_MAPA);
  service.nearbySearch(request, fun_generar_lugares_cerca);

}


function fun_limpiar_lugares_cerca(){

	var marker;

	for (var i = 0, marker; marker = GL_MARCADORES_LUGARES_CERCA[i]; i++) {
      marker.setMap(null);
    }

}

var GL_INTERVAL_MENSAJE_SIN_RESULTADOS;
function fun_generar_lugares_cerca(results, status) {
  if (status == google.maps.places.PlacesServiceStatus.OK) {
  	
  	$('#btn_borrar_lugares_cercanos').removeClass('oculto');
		clearInterval(GL_INTERVAL_MENSAJE_SIN_RESULTADOS);
		$('#mensaje_busqueda_lugares').addClass('oculto');

	    for (var i = 0; i < results.length; i++) {
	      fun_marcador_lugar_cerca(results[i]);
	    }
  	
  }else{
  	$('#btn_borrar_lugares_cercanos').addClass('oculto');

		clearInterval(GL_INTERVAL_MENSAJE_SIN_RESULTADOS);
  		$('#mensaje_busqueda_lugares').removeClass('oculto');

  		GL_INTERVAL_MENSAJE_SIN_RESULTADOS= setInterval(function(){
  			clearInterval(GL_INTERVAL_MENSAJE_SIN_RESULTADOS);
  			$('#mensaje_busqueda_lugares').addClass('oculto');
  		},4000);

  }
}


function fun_marcador_lugar_cerca(place) {
  var placeLoc = place.geometry.location;

  var marker = new google.maps.Marker({
    map: GL_MAPA,
    position: place.geometry.location,
    draggable: false,
    visible:true,
    icon: 'IMG/lugar_cercano.png', 
    animation: google.maps.Animation.DROP
  });

     GL_MARCADORES_LUGARES_CERCA.push(marker);

  google.maps.event.addListener(marker, 'click', function() {
    GL_INFO_WINDOW.setContent( '<img src="'+place.icon+'" style="width:40px; vertical-align:middle;"><span style="vertical-align:middle;">'+place.name+'</span>');
    GL_INFO_WINDOW.open(GL_MAPA, this);
  });
}

